![manifests • * —](https://img.shields.io/badge/manifests-*%20—-lightgrey)

# manifests — Você está aqui

**Path:** `manifests`  
**Role/Cor:** —  
**Zona:** LAB 8GB → LAB 256  

## Credenciais necessárias
- Passkey/keys conforme a operação.


## Função
Inventário de containers, rotas e políticas.

## Entradas permitidas (Inbound)
- Inputs da devops/build ou chamadas internas


## Saídas permitidas (Outbound)
- Artefatos para containers ou kernel


## Dados que passam por aqui
- Configs, manifests, scripts

## Dicas
- Nunca versionar segredos. Use placeholders e vars de ambiente.

---
_Navegação:_ [Resumo](../../SUMMARY.md  ) · [Guia](GUIDE.md)