Este pacote agrega:
1) Observabilidade + Orquestrador (Prometheus/Grafana/Loki/Promtail, PM2, stubs /metrics)
2) Integração de Repo/Git (endpoints no server, SDK/CLI TS, exemplos de átomos, git hook)

Cole o conteúdo no monorepo UBL 2.0. Em seguida:
- Rode os scripts de observabilidade (LAB 256 e 512)
- Construa o SDK/CLI (Node 20+)
- Habilite as rotas repo no ubl-server
