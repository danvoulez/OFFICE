Use orchestrate.sh com A1/B1; defina .env e execute push_bins.sh após build.
