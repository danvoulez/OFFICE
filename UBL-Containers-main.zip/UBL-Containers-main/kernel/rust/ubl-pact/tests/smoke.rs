#[test]
fn ubl_pact_smoke() {{ assert!(true); }}
