//! Conformance: static repo container MUST enforce Δ=0 and reject non-Observation.
#[test]
fn repo_delta_must_be_zero() {
    // Pseudocode placeholder for unit: ensure policy rejects Entropy for repo:// containers.
    assert!(true);
}
