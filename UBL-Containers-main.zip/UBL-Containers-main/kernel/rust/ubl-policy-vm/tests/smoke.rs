#[test]
fn ubl_policy_vm_smoke() {{ assert!(true); }}
