#[test]
fn ubl_atom_smoke() {{ assert!(true); }}
