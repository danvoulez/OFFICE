#[test]
fn ubl_link_smoke() {{ assert!(true); }}
