#[test]
fn ubl_runner_core_smoke() {{ assert!(true); }}
