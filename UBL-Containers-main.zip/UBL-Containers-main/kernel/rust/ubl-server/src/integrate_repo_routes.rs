// Adicione ao main.rs do ubl-server:
// use crate::repo_routes;
// let app = Router::new()
//   .merge(repo_routes::router())
//   .merge(other_routes);
