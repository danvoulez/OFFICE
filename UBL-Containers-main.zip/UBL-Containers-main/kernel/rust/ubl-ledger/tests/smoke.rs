#[test]
fn ubl_ledger_smoke() {{ assert!(true); }}
