Vetores GOLDEN e testes cruzados TS↔Rust entram aqui.
