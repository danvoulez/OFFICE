Regras TDLN determinísticas (fonte).
