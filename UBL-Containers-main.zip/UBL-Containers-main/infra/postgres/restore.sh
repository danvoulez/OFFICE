#!/usr/bin/env bash
set -euo pipefail
# restore + verify
