#!/usr/bin/env bash
set -euo pipefail
# init roles/dbs aqui
