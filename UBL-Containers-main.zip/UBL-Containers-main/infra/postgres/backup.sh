#!/usr/bin/env bash
set -euo pipefail
# pg_dump + compress
