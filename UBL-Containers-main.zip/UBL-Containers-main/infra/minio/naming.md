Padrão: ubl/projects/{project_id}/{kind}/{sha256}.{ext} + tags.json
