#!/usr/bin/env bash
# cria bucket + policy
