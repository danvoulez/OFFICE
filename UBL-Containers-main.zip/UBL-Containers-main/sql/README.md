![sql • * —](https://img.shields.io/badge/sql-*%20—-lightgrey)

# sql — Você está aqui

**Path:** `sql`  
**Role/Cor:** —  
**Zona:** LAB 256 (DB)  

## Credenciais necessárias
- Passkey/keys conforme a operação.


## Função
DDL do ledger/idempotency/observability/DR (Postgres).

## Entradas permitidas (Inbound)
- Inputs da devops/build ou chamadas internas


## Saídas permitidas (Outbound)
- Artefatos para containers ou kernel


## Dados que passam por aqui
- Configs, manifests, scripts

## Dicas
- Nunca versionar segredos. Use placeholders e vars de ambiente.

---
_Navegação:_ [Resumo](../../SUMMARY.md  ) · [Guia](GUIDE.md)